package com.IOE.cs.city_sync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitySyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
