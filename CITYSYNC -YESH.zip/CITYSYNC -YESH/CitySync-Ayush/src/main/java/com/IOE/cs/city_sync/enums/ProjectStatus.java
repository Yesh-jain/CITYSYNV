package com.IOE.cs.city_sync.enums;

public enum ProjectStatus {
    UNDERPROCESS , ACTIVE , COMPLETED;
}
