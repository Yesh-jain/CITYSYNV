package com.IOE.cs.city_sync.enums;

public enum Response {
    UNANSWERED, APPROVE, COLLAB, INVITED;
}
