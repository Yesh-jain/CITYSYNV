package com.IOE.cs.city_sync.Security.Service;

import com.IOE.cs.city_sync.Entities.CSUser;
import com.IOE.cs.city_sync.Repos.CSUserRepo;
import com.IOE.cs.city_sync.Security.User.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private static final Logger log = LoggerFactory.getLogger(CustomUserDetailsService.class);

    @Autowired
    private CSUserRepo userRepo;

    @Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    log.debug("DEBUG >>> Attempting login for username: {}", username);

    User user = userRepository.findByUsername(username);
    if (user == null) {
        log.debug("DEBUG >>> User not found in DB.");
        throw new UsernameNotFoundException("User not found");
    }

    log.debug("DEBUG >>> Found user: {}", user.getUsername());

    return new org.springframework.security.core.userdetails.User(
        user.getUsername(), user.getPassword(), new ArrayList<>()
    );
}

}
