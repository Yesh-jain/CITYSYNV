package com.IOE.cs.city_sync.Controllers;

import com.IOE.cs.city_sync.DTOs.*;
import com.IOE.cs.city_sync.Services.CSUserService;
import com.IOE.cs.city_sync.Services.DepartmentService;
import com.IOE.cs.city_sync.Services.MessageService;
import com.IOE.cs.city_sync.Services.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final CSUserService csUserService;
    private final DepartmentService departmentService;
    private final MessageService messageService;
    private final ResourceService resourceService;

    @Autowired
    public AdminController(CSUserService csUserService,
                           DepartmentService departmentService,
                           MessageService messageService,
                           ResourceService resourceService) {
        this.csUserService = csUserService;
        this.departmentService = departmentService;
        this.messageService = messageService;
        this.resourceService = resourceService;
    }

    @GetMapping("")
    public String adminRole() {
        return "admin/admin-role";
    }

    @GetMapping("/role")
    public String adminPage() {
        return "admin/admin-rights";
    }

    @GetMapping("/register-user")
    public String registerUser(Model model) {
        model.addAttribute("csuserDto", new CSUserDTO());
        model.addAttribute("departments", departmentService.getAllDepartments());
        return "admin/registerUser";
    }

    @PostMapping("/add-user")
    public String userSubmission(@ModelAttribute CSUserDTO csuserdto, Model model) {
        try {
            csUserService.addUser(csuserdto);
            model.addAttribute("message", "Signup successful for " + csuserdto.getName());
        } catch (Exception e) {
            model.addAttribute("message", "Error while adding user: " + e.getMessage());
        }
        return "user/result";
    }

    @GetMapping("/showUsers")
    public String showUsers(Model model) {
        model.addAttribute("users", csUserService.getAllUsers());
        return "admin/showUsers";
    }

    @GetMapping("/register-department")
    public String registerDepartment(Model model) {
        model.addAttribute("departmentdto", new DepartmentDTO());
        return "admin/registerDept";
    }

    @PostMapping("/add-department")
    public String addDepartment(@ModelAttribute DepartmentDTO departmentdto, Model model) {
        try {
            departmentService.addDepartment(departmentdto);
            model.addAttribute("message", "Department registration successful for " + departmentdto.getName());
        } catch (Exception e) {
            model.addAttribute("message", "Error while adding department: " + e.getMessage());
        }
        return "user/result";
    }

    @GetMapping("/showAllMessages")
    public String showAllMessages(Model model) {
        model.addAttribute("allMessages", messageService.getAllMessages());
        return "admin/showAllMessages";
    }

    @GetMapping("/showResourcePool")
    public String showResourcePool(Model model) {
        model.addAttribute("allPooledResources", resourceService.getResourcePool());
        return "admin/showPooledResources";
    }
}
